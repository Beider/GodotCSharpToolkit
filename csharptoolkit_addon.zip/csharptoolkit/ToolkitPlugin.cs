#if TOOLS
using Godot;
using System;
using GodotCSharpToolkit.Misc;


[Tool]
public class ToolkitPlugin : EditorPlugin
{
	private const string AUTO_DEBUG_MENU = "DebugMenu";
	private const string AUTO_TOOLKIT_LOADER = "ToolkitLoader";


	public override void _EnterTree()
	{
		AddAutoloadSingleton(AUTO_DEBUG_MENU, "res://GodotCSharpToolkit/DebugMenu/DebugMenu.tscn");
		AddAutoloadSingleton(AUTO_TOOLKIT_LOADER, "res://GodotCSharpToolkit/ToolkitLoader.cs");
		AddProjectPath();
		AddDataPath();
	}

	public override void _ExitTree()
	{
		RemoveAutoloadSingleton(AUTO_DEBUG_MENU);
		RemoveAutoloadSingleton(AUTO_TOOLKIT_LOADER);

	}

	private void AddProjectPath()
	{
		ProjectSettings.SetSetting(Constants.SETTING_PATH_NAME, ProjectSettings.GlobalizePath("res://"));
		var propertyInfo = new Godot.Collections.Dictionary();
		propertyInfo.Add("name", Constants.SETTING_PATH_NAME);
		propertyInfo.Add("type", Godot.Variant.Type.String);
		propertyInfo.Add("hint", Godot.PropertyHint.Dir);
		propertyInfo.Add("hint_string", "Absolute project path");

		ProjectSettings.AddPropertyInfo(propertyInfo);
	}

	private void AddDataPath()
	{
		ProjectSettings.SetSetting(Constants.SETTING_DATA_PATH, Constants.DEFAULT_SETTING_DATA_PATH);
		var propertyInfo = new Godot.Collections.Dictionary();
		propertyInfo.Add("name", Constants.SETTING_DATA_PATH);
		propertyInfo.Add("type", Godot.Variant.Type.String);
		propertyInfo.Add("hint", Godot.PropertyHint.None);
		propertyInfo.Add("hint_string", "Relative data path");

		ProjectSettings.AddPropertyInfo(propertyInfo);

	}
}
#endif
